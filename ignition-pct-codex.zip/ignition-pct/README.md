# Ignition PCT — Codex workspace

This workspace is prepared for staged development of an Ignition Perspective 8.1.26 application.

Start by reading `PROJECT_CONTEXT.md`, `AGENTS.md`, and `ARCHITECTURE_DECISIONS.md`.

- `reference/` is read-only source material extracted from existing Ignition exports/resources.
- `src/themes/` is reserved for the new `crzi` / `crzi-pct` theme work.
- `src/project/` is reserved for the new Perspective project source/export structure.
- `docs/` is for concise audit/change manifests.
- `release/` is only for clean importable release artifacts.

Do not implement application screens until the current phase explicitly requests them.
