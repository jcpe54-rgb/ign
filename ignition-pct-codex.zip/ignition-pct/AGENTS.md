# AGENTS — Mandatory rules for Codex

Read PROJECT_CONTEXT.md and ARCHITECTURE_DECISIONS.md before any work.

## Reference material
`reference/` is READ-ONLY evidence from real Ignition resources.
- `reference/example/`: real developed Perspective project; use to understand export/resource structure and existing engineering patterns.
- `reference/themes-iconos/`: current Gateway themes/icons structure; use when auditing/building themes.
- `reference/estilos/`: current Designer/Perspective Style Classes reference.

Never modify, rename, reorganize or "clean" files under reference/. Do not blindly copy them into src/. Separate mandatory Ignition structure from project-specific choices.

## Compatibility
Target Ignition Perspective 8.1.26. Do not introduce APIs, JSON properties, components or resource structures solely known from later versions. When uncertain, inspect the reference resources and explicitly flag uncertainty before implementing.

## Change discipline
Work only within the scope of the current phase. Do not redesign or refactor approved unrelated resources. Do not create alternative A/B/C architectures unless a genuine technical blocker requires a decision.

## Project export discipline
When generating a release project ZIP, mirror the real Ignition export structure verified from reference/example. Validate JSON and internal paths/references. The release ZIP must not contain README files, screenshots, source references, temporary files, backups, tests or development-only artifacts.

## Architecture discipline
- Keep view hierarchy shallow.
- Do not create Mobile/Tablet/Desktop/1366/1920 duplicate trees.
- Promote a View to Common only when actually shared.
- Do not create a reusable View for something that is better solved by Theme or Style Class.
- Keep data-source logic separate from presentation.
- Prefer passing normalized objects through view.params to child views.
- view.custom is for internal state/processed data, not an unstructured dumping ground.
- Centralize calculations and configuration.
- Bindings are allowed when declarative/reactive behavior is appropriate; do not replace them with scripts merely to reduce count.
- Scripts should not manually paint data into many child components when params/property bindings solve it cleanly.

## Theme/style discipline
Theme inheritance is `light -> crzi -> crzi-[xxx]`; current child is `crzi-pct`.
Do not edit native light. Avoid copying native base CSS when inheritance/override is sufficient.
Theme and Perspective Style Classes are separate layers.
Do not use `ia_` for custom styles.
Use short semantic style names and avoid application-specific prefixes on general Style Classes.

## Documentation
For each implementation phase, provide a concise change manifest outside the Ignition release ZIP: created, modified, reused, validation performed, and future real-data integration points. Do not produce long generic documentation.
