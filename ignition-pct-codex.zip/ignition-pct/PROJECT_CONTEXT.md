# PROJECT CONTEXT — Ignition PCT

## Objective
Build a production-monitoring application in Ignition Perspective 8.1.26. The initial implementation must be functionally complete using demo/simulated data. Demo applies to the data source only: navigation, filters, KPIs, states, timelines, historical views, tables/charts, report generation, Excel export, generated-report browsing and settings must work.

The future programmer must be able to replace the demo data layer with Tags, Tag Historian and/or Named Queries/PostgreSQL without rebuilding the UI.

## Platform and viewport
- Ignition Perspective 8.1.26 only. Do not assume 8.3 APIs/features.
- Desktop only.
- Target: 1920x1080.
- Minimum supported: 1366x768.
- No mobile/tablet variants or duplicate views by resolution.
- Overview TV is outside the initial desktop project and may become a separate project later.
- Do not impose Flex or Coordinate globally. Choose the appropriate Perspective container for each composition. Coordinate is primarily for spatial/process layouts such as unifilars, tanks, valves and overlays, which are not the main pattern here.

## Functional modules
1. Overview — current operational state.
2. History — historical exploration by period/shift/line/metric, graph/table, downtime timeline, Excel.
3. Reports — current report is the primary report screen and can consolidate data while a shift is in progress.
4. Generated Reports — secondary report view for searching/filtering previously generated reports, viewing one and downloading/generating Excel.
5. Settings — central configuration for shifts, groups, supervisors and approved application parameters.

## Approved view tree baseline
Views/
- 00.Common/
  - 01.Templates/
  - 02.Navigation/
- 01.Overview/
  - 00.Main
  - 01.Templates/
- 02.History/
  - 00.Main
  - 01.Templates/
- 03.Reports/
  - 00.Main
  - 01.Generated
  - 02.Templates/
- 04.Settings/
  - 00.Main
  - 01.Templates/

Keep nesting shallow. Do not add folders without a real responsibility. Common must remain small and contain only genuinely shared resources.

## Theme standard
Theme inheritance standard:
light -> crzi -> crzi-[xxx]

Current application theme: crzi-pct.
- crzi is the corporate visual base.
- crzi-[xxx] is the mandatory three-letter application theme convention.
- crzi-pct is the current Pasta Corta theme.
- Do not modify Ignition native themes.
- Do not duplicate light unnecessarily.
- Child themes should contain only necessary overrides/additions.
- Theme resources installed on the Gateway are independent from Perspective project Style Classes.

## Style responsibility
- Theme: global/native component appearance and shared visual variables.
- Perspective Style Class: reusable semantic visual variants inside Designer.
- Reusable View/template: reusable structure and behavior.
- view.params: input contract.
- view.custom: internal state/processed data.
- Binding: declarative/reactive connection when appropriate.
- Script: behavior/transformation only when it is the correct responsibility.
- Avoid inline styles unless truly dynamic.
- Do not use the reserved `ia_` prefix for custom styles.
- Names must be short and semantic; do not include the application name in general Style Classes.

## Data architecture
Prefer a normalized data contract:
source -> normalization/application model -> main view -> view.params -> child views.

Do not make every Label independently query the source. Property bindings to params/custom are valid and should not be replaced with scripts merely to reduce binding count. Centralize calculations and transformations to avoid duplication.

Confirmed production rules:
- 1 fardo = 12 kg.
- Ton = fardos * 0.012.
- Speed is shown as Ton/h and is based on a 5-minute window unless the implementation contract is later changed.
- Current operational states must distinguish running, stopped, fault, inactive and noData.
- Fault_Code: any nonzero/current fault code indicates a fault; no fault-code catalog is required in this phase.
- Operating Mode and Operating State are different concepts.
- Shift transitions reset visible current-shift accumulations as appropriate, while historical data remains stored.
- Shifts are configurable; do not hardcode schedules across views/scripts.

## Reports
03.Reports/00.Main remains the primary Reports screen. It shows/consolidates the selected/current period and can be used while the shift is in progress.
03.Reports/01.Generated is secondary and lists formally generated reports.
Generated reports must be treated as persisted snapshots/records, not live queries that silently change later.
The report presentation should be reusable so it can consume current/live report data or stored report data without duplicating the visual structure.

## UX/UI constraints
The approved design is implementation reference, not inspiration. Do not redesign it during development.
Operational colors are semantic: green running, yellow stopped without fault, red stopped with fault, gray inactive. Historical downtime timeline uses green running, red stopped, gray inactive. Analytical charts should use neutral analytical colors rather than operational state colors unless state is the information being encoded.
No OEE or unconfirmed efficiency/nominal metrics.

## Engineering principles
- Reuse over duplication.
- Single source of truth.
- Low coupling between data source and presentation.
- Small, responsibility-focused reusable functions.
- No repeated formulas in multiple views.
- No unnecessary scripts or bindings.
- Comment non-obvious implementation logic and future real-data integration points.
- Keep the application light and predictable under normal data load.
- Never create backup/test/dev resources inside production project exports.
